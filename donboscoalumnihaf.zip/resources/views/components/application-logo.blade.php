<img src="{{ asset('images/misc/logo.png') }}" class="w-20 h-20 fill-current">
