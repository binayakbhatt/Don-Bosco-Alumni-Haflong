<img src="<?php echo e(asset('images/misc/logo.png')); ?>" class="w-20 h-20 fill-current">
<?php /**PATH G:\donboscoalumni\resources\views/components/application-logo.blade.php ENDPATH**/ ?>