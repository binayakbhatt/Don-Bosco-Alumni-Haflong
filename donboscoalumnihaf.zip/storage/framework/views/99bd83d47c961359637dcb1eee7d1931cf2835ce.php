<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8"></div>

    <div class="py-12">

        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-12 bg-white border-b border-gray-200">
                    <div class="max-w-7xl mx-auto py-6">
                        <h2 class="flex items-center justify-center font-bold text-4xl text-blue-800 leading-tight">
                            Admin Dashboard
                        </h2>
                    </div>
                    <div class=" grid grid-cols-1 sm:grid-cols-1 md:grid-cols-4  gap-14 mt-6 px-24">

                        <a href="<?php echo e(route('user.index')); ?>"
                            class="block  max-w-sm p-6 bg-white border border-gray-200 
                            rounded-lg shadow-lg hover:bg-gray-100 hover:scale-105">
                            <h5 class="mb-2 text-xl font-bold tracking-tight text-gray-500 text-center">Alumni</h5>
                            <p class="font-normal text-blue-700 text-md md:text-6xl text-center"><?php echo e($alumni); ?></p>
                        </a>
                        <a href="<?php echo e(route('news.index')); ?>"
                            class="block max-w-sm p-6 bg-white border border-gray-200 
                             rounded-lg shadow-lg hover:bg-gray-100 hover:scale-105">
                            <h5 class="mb-2 text-xl font-bold tracking-tight text-gray-500 text-center">News</h5>
                            <p class="font-normal text-blue-700 text-md md:text-6xl text-center"><?php echo e($news); ?></p>
                        </a>
                        <a href="#"
                            class="block  max-w-sm p-6 bg-white border border-gray-200 
                             rounded-lg shadow-lg hover:bg-gray-100 hover:scale-105">
                            <h5 class="mb-2 text-xl font-bold tracking-tight text-gray-500 text-center">Event</h5>
                            <p class="font-normal text-blue-700 text-md md:text-6xl text-center">2</p>
                        </a>
                        <a href="#"
                            class="block   max-w-sm p-6 bg-white border border-gray-200 
                             rounded-lg shadow-lg hover:bg-gray-100 hover:scale-105">
                            <h5 class="mb-2 text-xl font-bold tracking-tight text-gray-500 text-center">Blog</h5>
                            <p class="font-normal text-blue-700 text-md md:text-6xl text-center">180</p>
                        </a>
                        <a href="#"
                            class="block   max-w-sm p-6 bg-white border border-gray-200 
                             rounded-lg shadow-lg hover:bg-gray-100 hover:scale-105">
                            <h5 class="mb-2 text-xl font-bold tracking-tight text-gray-500 text-center">Categories</h5>
                            <p class="font-normal text-blue-700 text-md md:text-6xl text-center">5</p>
                        </a>

                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH G:\donboscoalumni\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>