<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8"></div>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-12 bg-white border-b border-gray-200">
                    <div class="max-w-7xl mx-auto py-6">
                        <section class="bg-white">
                            <div
                                class="gap-16 items-center py-8 px-4 mx-auto max-w-screen-xl lg:grid lg:grid-cols-2 lg:py-16 lg:px-6">
                                <div class="font-light text-gray-700 sm:text-lg ">
                                    <h2
                                        class="mb-4 text-4xl tracking-tight font-extrabold 
                                        text-gray-900 text-justify">
                                        <?php echo e($news_single->headline); ?>

                                    </h2>
                                    <h5 class="text-gray-900 text-xl font-medium mb-2">
                                        <?php echo e(Carbon\Carbon::parse($news_single->date)->format('d-m-Y')); ?></h5>
                                    <p class="mb-4 text-justify"><?php echo e($news_single->body); ?></p>
                                </div>
                                <div class="grid grid-cols-1 gap-4 mt-8">
                                    <?php if($news_single->image_link): ?>
                                        <img src="<?php echo e(asset('images/news/' . $news_single->image_link)); ?>"
                                            alt="<?php echo e($news_single->slug); ?>" class="w-full rounded-lg">
                                    <?php endif; ?>
                                </div>
                            </div>
                        </section>

                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH G:\donboscoalumni\resources\views/news/show.blade.php ENDPATH**/ ?>