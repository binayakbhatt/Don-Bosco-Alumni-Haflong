This Website serves a platform for connecting Alumni of Don Bosco High School Haflong with the students of the school.
